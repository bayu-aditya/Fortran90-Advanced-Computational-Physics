Cara Menjalakan Program [Linux Ubuntu]: 
    $ bash run.sh

Untuk melihat hasil fungsi gelombang terdapat di dalam directory :
    Gambar                  : "Grafik/fungsi_radial.png"
    Data fungsi gelombang   : "Data/euler_orde2_1.dat" untuk l = 1
                              "Data/euler_orde2_2.dat" untuk l = 2