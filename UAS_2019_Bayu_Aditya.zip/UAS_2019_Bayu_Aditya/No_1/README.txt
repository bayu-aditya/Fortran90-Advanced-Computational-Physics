Cara Menjalakan Program [Linux Ubuntu]: 
    $ bash run.sh

Untuk melihat hasil interpolasi dari data terdapat di dalam directory :
    Gambar              : "Data/interpolasi_lagrange.png"
    Data interpolasi    : "Data/lagrange_plot.dat"