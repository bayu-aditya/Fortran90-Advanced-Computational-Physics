Cara Menjalakan Program [Linux Ubuntu]: 
    $ bash run.sh

Untuk mengubah nilai matriks terdapat di dalam directory :
    "Data/matriks.dat"