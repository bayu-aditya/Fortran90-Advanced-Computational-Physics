Cara Menjalakan Program [Linux Ubuntu]: 
    $ bash run.sh

Cara Menampilkan Plot 3D [Linux Ubuntu]:
    $ python plot.py Data/Hasil_Hyperbolic.dat